#ifndef ODP_HISI_H
#define ODP_HISI_H

#include <odp/pool.h>
#include <odp_packet.h>

int odp_init_hisilicon(void);
#endif
