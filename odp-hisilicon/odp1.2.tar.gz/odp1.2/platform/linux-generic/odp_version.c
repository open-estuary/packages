/* Copyright (c) 2015, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

#include <odp/version.h>

const char *odp_version_api_str(void)
{
	return ODP_VERSION_API_STR;
}
