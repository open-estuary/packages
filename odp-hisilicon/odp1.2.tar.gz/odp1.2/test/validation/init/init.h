/* Copyright (c) 2015, Linaro Limited
 * All rights reserved.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 */

#ifndef _ODP_TEST_INIT_H_
#define _ODP_TEST_INIT_H_

#include <CUnit/Basic.h>

/* test functions: */
void init_test_odp_init_global_replace_abort(void);
void init_test_odp_init_global_replace_log(void);
void init_test_odp_init_global(void);

/* test arrays: */
extern CU_TestInfo init_suite_abort[];
extern CU_TestInfo init_suite_log[];
extern CU_TestInfo init_suite_ok[];

/* test registry: */
extern CU_SuiteInfo init_suites_abort[];
extern CU_SuiteInfo init_suites_log[];
extern CU_SuiteInfo init_suites_ok[];

/* main test program: */
int init_main_abort(void);
int init_main_log(void);
int init_main_ok(void);

#endif
