#!/bin/sh

./odp_build.sh
./app_build.sh
./user_build.sh
./copy.sh

